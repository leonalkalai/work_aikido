# Wrap Up

Alright guys, I really hope that you enjoyed this course. I tried to include as much as I could and fit it into a single project. We learned all about routes, controllers, views, components, models, migrations and the list goes on. My advice now is to take what you've learned and use those skills to create some more of your own projects. Courses and tutorials can only help you so much. Getting into the weeds and figuring something out on your own from start to finish is one of the most valuable things that you can do in your learning experience.

Once you feel ready you can move on to either applying for positions or start taking clients, or build a product like a SaaS. Whatever it is you learn Laravel to be able to do. 

Move on to learn about other tools in the Laravel ecosystem as well. Before you know it you'll be a pro.

Thanks so much for taking this course guys. I really appreciate it and I hope you enjoyed it and found it fulfiling. See you in the next course.